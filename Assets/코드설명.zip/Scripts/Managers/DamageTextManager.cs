using UnityEngine;
using NeoSurvive.UI;

namespace NeoSurvive.Managers
{
  public class DamageTextManager : MonoBehaviour
  {
    public static DamageTextManager Instance { get; private set; }

    public GameObject damageTextPrefab;

    void Awake()
    {
      if (Instance == null) Instance = this;
      else Destroy(gameObject);
    }

    public void ShowDamageText(Vector3 position, float damage)
    {
      if (SettingsManager.Instance != null && !SettingsManager.Instance.showDamageNumbers) return;

      GameObject obj;
      if (damageTextPrefab != null)
      {
        obj = Instantiate(damageTextPrefab, position, Quaternion.identity);
      }
      else
      {
        obj = new GameObject("DamageText");
        obj.transform.position = position;
        obj.AddComponent<DamageText>();
      }

      DamageText dt = obj.GetComponent<DamageText>();
      if (dt != null) dt.Setup(damage, position);
    }
  }
}
